<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="col-12 ">
		<img class=" col-12 " style="height: 500px" src="<?= SCRIPTS . 'img' . DIRECTORY_SEPARATOR . 'cart.png' ?>">
	</div>

</body>
</html>