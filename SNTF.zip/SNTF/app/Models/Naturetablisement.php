<?php

namespace App\Models;

class Naturetablisement extends Model
{
    protected $table = 'nature_etablisement'; 

}
