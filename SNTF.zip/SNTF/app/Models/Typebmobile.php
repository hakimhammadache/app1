<?php

namespace App\Models;

class Typebmobile extends Model
{
    protected $table = 'type_bien_mobile'; 

}
