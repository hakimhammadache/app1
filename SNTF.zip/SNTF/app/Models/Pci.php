<?php

namespace App\Models;

class Pci extends Model
{
    protected $table = 'pci'; 

}
