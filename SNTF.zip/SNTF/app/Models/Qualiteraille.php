<?php

namespace App\Models;

class Qualiteraille extends Model
{
    protected $table = 'qualite_rail'; 

}