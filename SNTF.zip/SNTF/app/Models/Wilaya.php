<?php

namespace App\Models;

class Wilaya extends Model
{
    protected $table = 'wilaya'; 

}
