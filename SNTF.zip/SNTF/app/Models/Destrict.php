<?php

namespace App\Models;

class Destrict extends Model
{
    protected $table = 'destricte'; 
}