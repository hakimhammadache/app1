<?php

namespace App\Models;

class Etatterrain extends Model
{
    protected $table = 'etat_terrain'; 

}
