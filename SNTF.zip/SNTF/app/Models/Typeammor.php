<?php

namespace App\Models;

class Typeammor extends Model
{
    protected $table = 'type_ammortisement'; 
}
