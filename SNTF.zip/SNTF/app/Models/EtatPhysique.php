<?php

namespace App\Models;

class EtatPhysique extends Model
{
    protected $table = 'etat_physique'; 

}
