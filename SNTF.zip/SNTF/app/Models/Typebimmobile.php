<?php

namespace App\Models;

class Typebimmobile extends Model
{
    protected $table = 'type_bien_immobile'; 

    
}
